package DataClasses;

//To Implement some way to track gaming time?
public class GameSchedule {
}
