package com.example.authapp;

import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterUserPreference extends AppCompatActivity implements View.OnClickListener {
    @Override
    public void onClick(View view) {

    }
}
