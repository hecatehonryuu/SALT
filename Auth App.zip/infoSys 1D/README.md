# S.A.L.T.
Infosys 1D

1) Clone repos
2) Open repos in android studios 
3) Create device (Next to run button)
4) use default device (pixel 2)
5) choose tiramisu (not tiramisuprivacy)
6) Click run

At the top of android studio, select Git (Near Help) to make pulls/commits
